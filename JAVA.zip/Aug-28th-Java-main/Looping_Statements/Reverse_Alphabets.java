package Looping_Statements;

// write a program to print reverse all alphabets from Z to A

public class Reverse_Alphabets {

	public static void main(String[] args) {

		for (char i = 'Z'; i >= 'A'; i--) {
			System.out.println(i);
		}
	}
}

// Output: 

//Z
//Y
//X
//W
//V
//U
//T
//S
//R
//Q
//P
//O
//N
//M
//L
//K
//J
//I
//H
//G
//F
//E
//D
//C
//B
//A
