package Looping_Statements;

//write a program to print all alphabets from a to z.

public class Alphabets {

	public static void main(String[] args) {

		for (char i = 'a'; i <= 'z'; i++) {

			System.out.println(i);
		}
	}

}

//output :

//a
//b
//c
//d
//e
//f
//g
//h
//i
//j
//k
//l
//m
//n
//o
//p
//q
//r
//s
//t
//u
//v
//w
//x
//y
//z
