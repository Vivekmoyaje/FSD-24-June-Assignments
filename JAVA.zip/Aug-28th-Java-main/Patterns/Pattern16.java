package Patterns;

public class Pattern16 {

	public static void main(String[] args) {

		int a = 5;

		for (int i = a; i >= 1; i--) {
			for (int j = a; j >= i; j--) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
	}

}

//5 
//5 4 
//5 4 3 
//5 4 3 2 
//5 4 3 2 1
