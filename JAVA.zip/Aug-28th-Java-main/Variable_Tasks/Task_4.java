package Variable_Tasks;

/*Exercise 4: Concatenate two strings.
Write a Java program that concatenates two strings and displays the result. 
Declare two String variables and assign values to them.*/

public class Task_4 {

	public static void main(String[] args) {
		String name1 = "Hello";
		String name2 = "World";

		System.out.println(name1 + " " + name2);
	}

}
