package Variable_Tasks;

/*Exercise 2: Calculate the sum of two integers.
  Write a Java program that calculates the sum of two integers. 
  Declare two integer variables and assign values to them.*/

public class Task_2 {

	public static void main(String[] args) {

		int num1, num2;
		num1 = 34;
		num2 = 45;

		int sum = num1 + num2;

		System.out.println(num1 + " + " + num2 + " = " + sum);
	}

}
